package com.freeyou

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

class BlockerPackage : ReactPackage {
    override fun createNativeModules(ctx: ReactApplicationContext): MutableList<NativeModule> =
        mutableListOf(BlockerModule(ctx))
    override fun createViewManagers(ctx: ReactApplicationContext): MutableList<ViewManager<*, *>> =
        mutableListOf()
}
