package com.freeyou

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*

/**
 * הצלצול של משימת הגוף.
 * שירות חזית: ממשיך לצלצל גם אם סוגרים את האפליקציה או מנקים אותה מהמסך האחרון,
 * מתעלם ממצב שקט, ומעלה את עוצמת ההתראה בהדרגה. נעצר רק דרך stopAlarm() —
 * כלומר רק אחרי שהמשימה אומתה או אחרי כפתור החירום.
 */
class AlarmService : Service() {

    private var player: MediaPlayer? = null
    private var vib: Vibrator? = null
    private val ch = "freeyou_mission"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val night = intent?.getBooleanExtra("night", false) ?: false
        startForeground(42, buildNotification(night))
        ring()
        return START_STICKY
    }

    private fun buildNotification(night: Boolean): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val c = NotificationChannel(ch, "משימת גוף", NotificationManager.IMPORTANCE_HIGH).apply {
                setBypassDnd(true)
                enableVibration(true)
                setSound(null, null) // הצליל מנוגן ידנית כדי שלא ייעצר עם ההתראה
            }
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(c)
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("freeyou_route", "mission")
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, ch)
            .setContentTitle("הדיבורים נגמרו. עכשיו הגוף.")
            .setContentText(if (night) "פרוטוקול ביתי, 12 דקות" else "צא מהבית. הצלצול נפסק כשתתרחק 250 מטר.")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(open, true)   // פותח את המסך גם כשהטלפון נעול
            .setContentIntent(open)
            .build()
    }

    private fun ring() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        player = MediaPlayer().apply {
            setDataSource(this@AlarmService, uri)
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            isLooping = true
            prepare()
            start()
        }
        // ערוץ ההתראה מועלה בהדרגה — לא זורק אותו מהמיטה בבת אחת
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        am.setStreamVolume(AudioManager.STREAM_ALARM, (max * 0.45).toInt(), 0)
        Handler(Looper.getMainLooper()).postDelayed({
            am.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
        }, 45_000)

        vib = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            (getSystemService(VibratorManager::class.java)).defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(Vibrator::class.java)
        val pattern = longArrayOf(0, 420, 200, 420, 900)
        vib?.vibrate(VibrationEffect.createWaveform(pattern, 0))
    }

    override fun onDestroy() {
        player?.run { if (isPlaying) stop(); release() }
        vib?.cancel()
        super.onDestroy()
    }
}
