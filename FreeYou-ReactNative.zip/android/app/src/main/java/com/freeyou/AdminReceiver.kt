package com.freeyou

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * הגנת הסרה. כשמצב קפדני פעיל, האפליקציה רשומה כמנהל התקן
 * ואי אפשר להסיר אותה עד שמבטלים דרך מנגנון שחרור בתוך האפליקציה.
 */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        BlockRepo.init(context)
        return if (BlockRepo.strict)
            "מצב קפדני פעיל. פתח את FreeYou והשתמש במנגנון שחרור."
        else
            "ההגנה תבוטל."
    }
}
