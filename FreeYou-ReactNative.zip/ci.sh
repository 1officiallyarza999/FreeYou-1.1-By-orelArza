#!/usr/bin/env bash
# כל לוגיקת הבנייה. ה-workflow בגיטהאב רק קורא לסקריפט הזה.
set -e

echo "==> בוחר Java 17"
for j in /usr/lib/jvm/temurin-17-jdk-amd64 /usr/lib/jvm/java-17-openjdk-amd64; do
  [ -d "$j" ] && export JAVA_HOME="$j" && break
done
export PATH="$JAVA_HOME/bin:$PATH"
java -version

echo "==> בודק Android SDK"
export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
echo "SDK: $ANDROID_HOME"

echo "==> מרכיב את הפרויקט"
export FREEYOU_OUT="${FREEYOU_OUT:-$PWD/_build/FreeYouApp}"
mkdir -p "$(dirname "$FREEYOU_OUT")"
bash setup.sh

echo "==> בונה APK"
cd "$FREEYOU_OUT/android"
chmod +x gradlew
./gradlew assembleRelease --no-daemon

echo "==> אוסף את הקובץ"
cd - > /dev/null
mkdir -p out
cp "$FREEYOU_OUT"/android/app/build/outputs/apk/release/*.apk out/FreeYou.apk
ls -lh out/
echo "==> מוכן"
