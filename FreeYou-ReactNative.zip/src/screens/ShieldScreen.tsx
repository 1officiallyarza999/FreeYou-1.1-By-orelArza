import React, {useEffect, useState} from 'react';
import {View, ScrollView, TextInput, Alert} from 'react-native';
import Glass from '../components/Glass';
import {Title, H2, P, Tiny, Row, Btn, Switch, Pill} from '../components/UI';
import {useStore, attemptsToday} from '../store';
import Blocker from '../native/Blocker';
import {T, F} from '../theme';

// רשימות סינון ציבוריות ומתוחזקות — לא רשימה שאני כותב ידנית
const ADULT_LIST = 'https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn/hosts';

export default function ShieldScreen({go}: {go: (r: string) => void}) {
  const {s, set} = useStore();
  const [v, setV] = useState('');
  const [acc, setAcc] = useState(true);
  const [overlay, setOverlay] = useState(true);

  useEffect(() => {
    Blocker.isAccessibilityEnabled().then(setAcc);
    Blocker.canDrawOverlays().then(setOverlay);
  }, []);

  const guard = (fn: () => void) =>
    s.strict ? Alert.alert('מצב קפדני פעיל', 'שינוי דורש מנגנון שחרור.') : fn();

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 130}} showsVerticalScrollIndicator={false}>
      <Title style={{marginBottom: 14}}>החומה</Title>

      {(!acc || !overlay) && (
        <Glass style={{marginBottom: 12, borderColor: 'rgba(251,46,107,0.5)'}}>
          <Pill label="החסימה לא פעילה" tone="r" />
          <P style={{marginVertical: 10}}>
            בלי ההרשאות האלה FreeYou הוא רק ממשק יפה. שתי לחיצות והחומה עומדת.
          </P>
          {!acc && <Btn label="הפעל את שירות הנגישות" kind="cool" onPress={Blocker.openAccessibilitySettings} />}
          {!overlay && <Btn label="אשר הצגה מעל אפליקציות" kind="ghost" style={{marginTop: 8}} onPress={Blocker.openOverlaySettings} />}
        </Glass>
      )}

      <Glass>
        <Row>
          <View style={{flex: 1}}>
            <P style={{color: T.txt, fontFamily: F.bodyBold}}>חסימה אוטומטית של תוכן 18+</P>
            <Tiny>רשימת סינון ציבורית מתוחזקת, מתעדכנת בלחיצה</Tiny>
          </View>
          <Switch on={s.autoAdult} onPress={() => guard(() => set({autoAdult: !s.autoAdult}))} />
        </Row>
        <Row>
          <View style={{flex: 1}}>
            <P style={{color: T.txt, fontFamily: F.bodyBold}}>חסימת גלילה אינסופית</P>
            <Tiny>חוסם פיד ורילס, משאיר הודעות וחיפוש</Tiny>
          </View>
          <Switch on={s.autoScroll} onPress={() => guard(() => set({autoScroll: !s.autoScroll}))} />
        </Row>
        <Btn label="עדכן את רשימת הדומיינים" kind="ghost" style={{marginTop: 12}}
          onPress={() => Blocker.updateBlocklist(ADULT_LIST)
            .then(n => Alert.alert('החומה עודכנה', `${n.toLocaleString()} דומיינים נטענו.`))
            .catch(() => Alert.alert('לא הצלחתי להוריד', 'בדוק חיבור לאינטרנט.'))} />
      </Glass>

      <Glass style={{marginTop: 12}}>
        <H2>רשימה ידנית</H2>
        <View style={{flexDirection: 'row-reverse', gap: 8}}>
          <TextInput
            value={v} onChangeText={setV} placeholder="דומיין או שם חבילה"
            placeholderTextColor="rgba(244,245,247,0.3)"
            style={{flex: 1, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 16,
              borderWidth: 1, borderColor: T.edge, color: T.txt, paddingHorizontal: 15,
              fontFamily: F.body, textAlign: 'right'}} />
          <Btn label="הוסף" kind="cool" style={{width: 88}}
            onPress={() => {if (v.trim()) {set({blocked: [...s.blocked, v.trim()]}); setV('');}}} />
        </View>
        {s.blocked.length === 0
          ? <Tiny style={{marginTop: 12}}>הרשימה ריקה. הוסף כאן כל אתר או אפליקציה שגונבים לך את הערב.</Tiny>
          : s.blocked.map((b, i) => (
            <Row key={i}>
              <View style={{flexDirection: 'row-reverse', alignItems: 'center', gap: 9, flex: 1}}>
                <Pill label="חסום" tone="r" />
                <P style={{color: T.txt}}>{b}</P>
              </View>
              <Btn label="הסר" kind="ghost" style={{width: 74}} disabled={s.strict}
                onPress={() => set({blocked: s.blocked.filter((_, j) => j !== i)})} />
            </Row>
          ))}
      </Glass>

      <Glass style={{marginTop: 12}}>
        <Row>
          <View style={{flex: 1}}>
            <P style={{color: T.txt, fontFamily: F.bodyBold}}>מצב קפדני</P>
            <Tiny>{s.strict ? 'נעול. גם הסרת האפליקציה חסומה.' : 'נועל חסימות והופך את FreeYou לבלתי-נמחק'}</Tiny>
          </View>
          <Switch on={s.strict} onPress={() => {
            if (s.strict) return go('unlock');
            set({strict: true});
            Blocker.requestDeviceAdmin();
          }} />
        </Row>
        {s.strict && <Btn label="בקשת שחרור" kind="ghost" style={{marginTop: 12}} onPress={() => go('unlock')} />}
      </Glass>

      <Glass style={{marginTop: 12}}>
        <H2>מה קורה כשתנסה בכל זאת</H2>
        <Row><View style={{flexDirection: 'row-reverse', gap: 9, alignItems: 'center', flex: 1}}>
          <Pill label="ניסיון 1" /><P style={{flex: 1}}>מחברת. חייב לכתוב "יומנו של גבר:"</P></View></Row>
        <Row><View style={{flexDirection: 'row-reverse', gap: 9, alignItems: 'center', flex: 1}}>
          <Pill label="ניסיון 2" tone="r" /><P style={{flex: 1}}>משימת גוף. הצלצול לא נפסק עד שיצאת.</P></View></Row>
        <Tiny style={{marginTop: 10}}>ניסיונות היום: {attemptsToday(s)}</Tiny>
        <Btn label="הדגם את רגע העצירה" kind="ghost" style={{marginTop: 12}}
          onPress={() => go('intercept')} />
      </Glass>
    </ScrollView>
  );
}
