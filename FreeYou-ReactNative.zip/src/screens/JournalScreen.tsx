import React, {useState} from 'react';
import {View, TextInput, ScrollView} from 'react-native';
import Glass from '../components/Glass';
import {Title, P, Tiny, Btn, Pill} from '../components/UI';
import {useStore} from '../store';
import {T, F} from '../theme';

export const PREFIX = 'יומנו של גבר:';
const MIN = 180;

/**
 * מסך הניסיון הראשון. לא כפתור "המשך בכל זאת" —
 * המחברת היא הדרך היחידה קדימה, וכדי לכתוב אותה צריך את החלק החושב שבך.
 */
export default function JournalScreen({forced, done}: {forced?: boolean; done: () => void}) {
  const {s, set} = useStore();
  const [txt, setTxt] = useState(PREFIX + ' ');

  const okPrefix = txt.startsWith(PREFIX);
  const body = txt.slice(PREFIX.length).trim();
  const ok = okPrefix && body.length >= MIN;

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 40}} showsVerticalScrollIndicator={false}>
      <Title style={{fontSize: 30, marginBottom: 10}}>
        {forced ? 'עצור. לפני שאתה נכנס.' : 'יומנו של גבר'}
      </Title>
      <P style={{marginBottom: 14}}>
        התחל את הרשומה במילים "{PREFIX}" ואז כתוב לפחות {MIN} תווים. זה לא עונש — זו הדרך היחידה
        להכניס את החלק החושב שלך לחדר לפני שהדחף מחליט במקומך.
      </P>

      <Glass>
        <Tiny style={{marginBottom: 10}}>
          מה הרגשתי בדיוק רגע לפני? · מה באמת חיפשתי שם? · מה זה יעלה לי מחר בבוקר? · מה אני בוחר לעשות במקום, בעשר הדקות הקרובות?
        </Tiny>
        <TextInput
          value={txt} onChangeText={setTxt} multiline autoFocus
          textAlignVertical="top" textAlign="right"
          style={{minHeight: 200, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 16,
            borderWidth: 1, borderColor: T.edge, color: T.txt, padding: 14,
            fontFamily: F.body, fontSize: 15, lineHeight: 25}} />
        <View style={{flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginTop: 10}}>
          <Tiny>{body.length} / {MIN}</Tiny>
          <Pill tone={ok ? 'g' : 'r'} label={!okPrefix ? 'חסר הפתיח' : body.length < MIN ? 'ממשיך לכתוב' : 'מוכן'} />
        </View>
      </Glass>

      <Btn label="שמור וסגור" kind="cool" disabled={!ok} style={{marginTop: 14}}
        onPress={() => {
          set({
            journals: [...s.journals, {date: new Date().toLocaleString('he-IL'), text: txt}],
            urges: s.urges + 1,
          });
          done();
        }} />
    </ScrollView>
  );
}
