import React, {useEffect, useRef, useState} from 'react';
import {View, Text, Animated, Easing, Vibration, ScrollView} from 'react-native';
import Svg, {Defs, RadialGradient, Stop, Circle} from 'react-native-svg';
import Tts from 'react-native-tts';
import Glass from '../components/Glass';
import {P, Tiny, Btn, Pill} from '../components/UI';
import {useStore, daysClean} from '../store';
import {interceptLine, ownWords, INTERCEPT_PROMPT, Ctx} from '../data/mentorLines';
import {askMentor} from '../mentor';
import {T, F, W} from '../theme';

/**
 * המסך שקופץ בשנייה שבה נעצרה כניסה לאתר חסום.
 *
 * הקול נשמע מיד ממאגר מקומי — אין המתנה לרשת ברגע כזה.
 * במקביל יוצאת בקשה למנטור החי, ואם היא חוזרת תוך כמה שניות
 * הוא ממשיך לדבר. אם לא, המשפט המקומי עמד בפני עצמו.
 */
export default function InterceptScreen({attempt, next}: {attempt: number; next: () => void}) {
  const {s} = useStore();
  const ctx: Ctx = {
    reasons: s.reasons, days: daysClean(s), attempt, hour: new Date().getHours(),
  };

  const [line] = useState(() => interceptLine(ctx));
  const [reason] = useState(() => ownWords(ctx));
  const [extra, setExtra] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  const pulse = useRef(new Animated.Value(0)).current;
  const fade = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Vibration.vibrate(90);

    Animated.timing(fade, {toValue: 1, duration: 550, useNativeDriver: true}).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {toValue: 1, duration: 1900, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
        Animated.timing(pulse, {toValue: 0, duration: 1900, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
      ]),
    ).start();

    // מדבר מיד
    Tts.setDefaultLanguage('he-IL');
    Tts.setDefaultRate(0.46);
    Tts.setDefaultPitch(0.9);
    Tts.stop();
    Tts.speak(line);

    // הכפתור נפתח רק אחרי שהמשפט נאמר, כדי שלא ידלג בלי לשמוע
    const t = setTimeout(() => setReady(true), 6000);

    // ממשיך חי, אם הרשת מספיקה
    askMentor(
      [{role: 'user', content: INTERCEPT_PROMPT(ctx)}],
      s.reasons, ctx.days,
    ).then(txt => {
      if (txt && !txt.startsWith('אין לי חיבור')) {
        setExtra(txt);
        Tts.speak(txt);
      }
    });

    return () => {clearTimeout(t); Tts.stop();};
  }, []);

  const scale = pulse.interpolate({inputRange: [0, 1], outputRange: [1, 1.12]});
  const ORB = 168;

  return (
    <Animated.View style={{flex: 1, opacity: fade}}>
      <ScrollView contentContainerStyle={{paddingBottom: 30}} showsVerticalScrollIndicator={false}>
        <View style={{alignItems: 'center', marginTop: 10}}>
          <Pill label={attempt >= 2 ? 'ניסיון שני היום' : 'נעצרת'} tone={attempt >= 2 ? 'r' : undefined} />
        </View>

        {/* הנוכחות: לא אווטאר ולא פנים — אור */}
        <Animated.View style={{alignSelf: 'center', marginVertical: 24, transform: [{scale}]}}>
          <Svg width={ORB} height={ORB}>
            <Defs>
              <RadialGradient id="mentorOrb" cx="50%" cy="45%" r="50%">
                <Stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.95" />
                <Stop offset="22%" stopColor={T.amber} stopOpacity="0.7" />
                <Stop offset="55%" stopColor={T.violet} stopOpacity="0.35" />
                <Stop offset="100%" stopColor={T.violet} stopOpacity="0" />
              </RadialGradient>
            </Defs>
            <Circle cx={ORB / 2} cy={ORB / 2} r={ORB / 2} fill="url(#mentorOrb)" />
          </Svg>
        </Animated.View>

        <Text style={{fontFamily: F.display, fontWeight: W.display, fontSize: 22, lineHeight: 34,
          color: T.txt, textAlign: 'center', paddingHorizontal: 6}}>
          {line}
        </Text>

        {extra && (
          <Text style={{fontFamily: F.body, fontSize: 16, lineHeight: 27, color: 'rgba(244,245,247,0.82)',
            textAlign: 'center', marginTop: 16, paddingHorizontal: 6}}>
            {extra}
          </Text>
        )}

        {reason && (
          <Glass style={{marginTop: 22}} glow={T.amber}>
            <Tiny>במילים שלך</Tiny>
            <P style={{color: T.txt, fontSize: 15.5, marginTop: 4}}>"{reason}"</P>
          </Glass>
        )}

        <Btn
          label={ready ? (attempt >= 2 ? 'קיבלתי. יוצא.' : 'קיבלתי. אני כותב.') : 'תקשיב לי רגע'}
          kind={attempt >= 2 ? 'hot' : 'cool'}
          disabled={!ready}
          style={{marginTop: 22}}
          onPress={next}
        />
        <Tiny style={{textAlign: 'center', marginTop: 10}}>
          אין כאן כפתור "המשך בכל זאת". זה לא שכחה.
        </Tiny>
      </ScrollView>
    </Animated.View>
  );
}
