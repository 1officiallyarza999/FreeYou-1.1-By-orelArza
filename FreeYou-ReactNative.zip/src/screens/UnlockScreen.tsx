import React, {useEffect, useState} from 'react';
import {View, Text, TextInput, ScrollView, TouchableOpacity, Alert} from 'react-native';
import Glass from '../components/Glass';
import {Title, H2, P, Tiny, Btn} from '../components/UI';
import {useStore} from '../store';
import Blocker from '../native/Blocker';
import {T, F} from '../theme';

const PLEDGE = 'אני מבקש לפתוח את החומה ואני לוקח אחריות מלאה על מה שיקרה אחר כך';

/**
 * שלושה מנגנוני שחרור. הרעיון: אתה בונה את החומה כשאתה צלול
 * ומנסה לפרק אותה כשאתה לא — אז ל"אתה הצלול" יש כאן את המילה האחרונה.
 */
export default function UnlockScreen({close}: {close: () => void}) {
  const {s, set} = useStore();
  const [mode, setMode] = useState<'cool' | 'partner' | 'pledge' | null>(null);
  const [left, setLeft] = useState(3600);
  const [code, setCode] = useState('');
  const [txt, setTxt] = useState('');

  useEffect(() => {
    if (mode !== 'cool') return;
    const t = setInterval(() => setLeft(x => (x <= 1 ? 0 : x - 1)), 1000);
    return () => clearInterval(t);
  }, [mode]);

  const unlock = () => {
    if (mode === 'partner' && code.trim() !== s.partnerCode) return Alert.alert('קוד שגוי');
    set({strict: false});
    Blocker.releaseDeviceAdmin();
    close();
  };

  const opts = [
    {k: 'cool', ic: '⏳', t: 'המתנה של 60 דקות', d: 'בקש עכשיו, ייפתח בעוד שעה. רוב הדחפים לא שורדים את השעה הזו.'},
    {k: 'partner', ic: '🤝', t: 'קוד שותף אחריות', d: s.partnerCode ? 'התקשר לחבר שמחזיק את הקוד' : 'לא הגדרת קוד — קבע אחד במסך "אני"'},
    {k: 'pledge', ic: '✍️', t: 'הצהרה בכתב יד', d: 'העתקה מדויקת של משפט אחד, בלי הדבקה'},
  ];

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 40}} showsVerticalScrollIndicator={false}>
      <Title style={{fontSize: 30}}>שחרור מהחומה</Title>
      <P style={{marginVertical: 14}}>
        אתה בונה את החומה כשאתה צלול, ומנסה לפרק אותה כשאתה לא. שלושת המסלולים האלה קיימים
        כדי לתת ל"אתה הצלול" את המילה האחרונה.
      </P>

      {mode === null && opts.map(o => (
        <TouchableOpacity key={o.k} activeOpacity={0.85} style={{marginBottom: 10}}
          onPress={() => {
            if (o.k === 'partner' && !s.partnerCode) return Alert.alert('אין קוד שותף מוגדר');
            setMode(o.k as any);
          }}>
          <Glass radius={22}>
            <Text style={{fontSize: 22, textAlign: 'right'}}>{o.ic}</Text>
            <Text style={{fontFamily: F.displayMid, fontSize: 15, color: T.txt, textAlign: 'right', marginTop: 6}}>{o.t}</Text>
            <Tiny>{o.d}</Tiny>
          </Glass>
        </TouchableOpacity>
      ))}

      {mode === 'cool' && (
        <Glass>
          <Text style={{fontFamily: F.display, fontSize: 52, color: T.txt, textAlign: 'center'}}>
            {String(Math.floor(left / 60)).padStart(2, '0')}:{String(left % 60).padStart(2, '0')}
          </Text>
          <Tiny style={{textAlign: 'center', marginTop: 8}}>
            אל תסתכל על השעון. לך לעשות משהו — ותחזור אם עוד בא לך.
          </Tiny>
          <Btn label={left > 0 ? 'נעול' : 'פתח את החומה'} kind="cool" disabled={left > 0} style={{marginTop: 14}} onPress={unlock} />
        </Glass>
      )}

      {mode === 'partner' && (
        <Glass>
          <H2>הזן את קוד השותף</H2>
          <TextInput value={code} onChangeText={setCode} placeholder="קוד בן 6 תווים"
            placeholderTextColor="rgba(244,245,247,0.3)" textAlign="right"
            style={{backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 16, borderWidth: 1,
              borderColor: T.edge, color: T.txt, padding: 14, fontFamily: F.body, marginBottom: 12}} />
          <Btn label="אמת ופתח" kind="cool" onPress={unlock} />
        </Glass>
      )}

      {mode === 'pledge' && (
        <Glass>
          <H2>העתק בדיוק</H2>
          <P style={{color: T.txt, fontSize: 15, marginBottom: 12}}>{PLEDGE}</P>
          <TextInput value={txt} onChangeText={setTxt} multiline contextMenuHidden textAlign="right"
            placeholder="הקלד כאן" placeholderTextColor="rgba(244,245,247,0.3)"
            style={{minHeight: 110, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 16, borderWidth: 1,
              borderColor: T.edge, color: T.txt, padding: 14, fontFamily: F.body, textAlignVertical: 'top'}} />
          <Btn label="פתח את החומה" kind="cool" style={{marginTop: 12}}
            disabled={txt.trim() !== PLEDGE} onPress={unlock} />
        </Glass>
      )}

      <Glass style={{marginTop: 14}}>
        <Tiny>
          כפתור החירום והמנטור פתוחים תמיד, גם במצב קפדני. אף פעם לא נועלים החוצה בן אדם שצריך עזרה.
        </Tiny>
      </Glass>

      <Btn label="חזור" kind="ghost" style={{marginTop: 12}} onPress={close} />
    </ScrollView>
  );
}
