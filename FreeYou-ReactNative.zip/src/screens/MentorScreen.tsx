import React, {useEffect, useRef, useState} from 'react';
import {View, Text, ScrollView, TouchableOpacity, PermissionsAndroid, Platform, Animated, Easing} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Voice from '@react-native-voice/voice';
import Tts from 'react-native-tts';
import Glass from '../components/Glass';
import {Title, P, Tiny, Btn} from '../components/UI';
import {useStore, daysClean} from '../store';
import {T, F} from '../theme';
import {askMentor, Msg} from '../mentor';

/** חיווי האזנה: חמישה פסים שנעים, כדי שיהיה ברור שהוא באמת שומע אותך */
function Waveform({active}: {active: boolean}) {
  const bars = useRef([...Array(5)].map(() => new Animated.Value(0.25))).current;
  useEffect(() => {
    if (!active) {
      bars.forEach(b => b.stopAnimation(() => b.setValue(0.25)));
      return;
    }
    const loops = bars.map((b, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(b, {toValue: 1, duration: 340 + i * 90, easing: Easing.inOut(Easing.quad), useNativeDriver: false}),
          Animated.timing(b, {toValue: 0.3, duration: 340 + i * 90, easing: Easing.inOut(Easing.quad), useNativeDriver: false}),
        ]),
      ),
    );
    loops.forEach((l, i) => setTimeout(() => l.start(), i * 110));
    return () => loops.forEach(l => l.stop());
  }, [active]);

  return (
    <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, height: 44}}>
      {bars.map((b, i) => (
        <Animated.View key={i} style={{
          width: 5, borderRadius: 3, backgroundColor: active ? T.amber : 'rgba(255,255,255,0.18)',
          height: b.interpolate({inputRange: [0, 1], outputRange: [7, 42]}),
        }} />
      ))}
    </View>
  );
}

export default function MentorScreen() {
  const {s} = useStore();
  const [chat, setChat] = useState<Msg[]>([]);
  const [listening, setListening] = useState(false);
  const [status, setStatus] = useState('לחיצה כדי לדבר');
  const sv = useRef<ScrollView>(null);

  useEffect(() => {
    Tts.setDefaultLanguage('he-IL');
    Tts.setDefaultRate(0.46);   // קצב דיבור טבעי בעברית
    Tts.setDefaultPitch(0.92);  // גוון נמוך, קול של אח גדול
    Voice.onSpeechResults = e => {
      const t = e.value?.[0];
      setListening(false);
      if (t) send(t);
    };
    Voice.onSpeechError = () => {setListening(false); setStatus('לא שמעתי. נסה שוב.');};
    return () => {Voice.destroy().then(Voice.removeAllListeners); Tts.stop();};
  }, [chat, s]);

  const send = async (text: string) => {
    const next = [...chat, {role: 'user' as const, content: text}];
    setChat(next);
    setStatus('חושב...');
    const reply = await askMentor(next, s.reasons, daysClean(s));
    setChat([...next, {role: 'assistant', content: reply}]);
    setStatus('לחיצה כדי לדבר');
    Tts.stop();
    Tts.speak(reply);
    setTimeout(() => sv.current?.scrollToEnd({animated: true}), 100);
  };

  const mic = async () => {
    if (listening) {await Voice.stop(); setListening(false); return;}
    if (Platform.OS === 'android') {
      const ok = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
      if (ok !== 'granted') return setStatus('צריך הרשאת מיקרופון');
    }
    Tts.stop();
    setListening(true);
    setStatus('מקשיב... דבר');
    await Voice.start('he-IL');
  };

  return (
    <View style={{flex: 1, paddingBottom: 118}}>
      <Title>המנטור</Title>
      <P style={{marginVertical: 8}}>לחץ על המיקרופון ודבר. הוא שומע עברית, עונה בקול, ולא שופט אותך.</P>

      <Glass style={{flex: 1, marginBottom: 10}} padding={10} glow={T.violet}>
        <ScrollView ref={sv} showsVerticalScrollIndicator={false}>
          {chat.length === 0 && (
            <View style={[b.msg, b.m]}>
              <Text style={b.t}>אני כאן. תגיד לי מה עובר עליך עכשיו — בלי לייפות, בלי להתנצל.</Text>
            </View>
          )}
          {chat.map((m, i) => (
            <View key={i} style={[b.msg, m.role === 'user' ? b.u : b.m]}>
              <Text style={b.t}>{m.content}</Text>
            </View>
          ))}
        </ScrollView>
      </Glass>

      <Waveform active={listening} />

      <TouchableOpacity onPress={mic} activeOpacity={0.85} style={{alignSelf: 'center', marginTop: 10}}>
        <LinearGradient
          colors={listening ? [T.rose, T.amber] : [T.violet, T.cyan]}
          style={{width: 88, height: 88, borderRadius: 44, alignItems: 'center', justifyContent: 'center',
            borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)'}}>
          <Text style={{fontSize: 32}}>🎤</Text>
        </LinearGradient>
      </TouchableOpacity>
      <Tiny style={{textAlign: 'center', marginTop: 10}}>{status}</Tiny>

      <View style={{flexDirection: 'row-reverse', gap: 8, marginTop: 14}}>
        {['קשה לי עכשיו', 'תזכיר לי למה התחלתי', 'נכשלתי אתמול'].map(q => (
          <Btn key={q} label={q} kind="ghost" style={{flex: 1}} onPress={() => send(q)} />
        ))}
      </View>
    </View>
  );
}

const b = {
  msg: {maxWidth: '84%' as const, padding: 13, borderRadius: 20, marginBottom: 10, borderWidth: 1, borderColor: T.edge},
  m: {alignSelf: 'flex-end' as const, backgroundColor: 'rgba(124,58,237,0.22)', borderBottomRightRadius: 7},
  u: {alignSelf: 'flex-start' as const, backgroundColor: 'rgba(255,255,255,0.09)', borderBottomLeftRadius: 7},
  t: {fontFamily: F.body, fontSize: 14.5, lineHeight: 23, color: T.txt, textAlign: 'right' as const},
};
