import React, {useEffect, useRef, useState} from 'react';
import {View, Text, Animated, Easing, ScrollView, Alert} from 'react-native';
import Glass from '../components/Glass';
import {Title, P, Btn} from '../components/UI';
import {useStore} from '../store';
import {T, F} from '../theme';

/** רכיבה על הגל: 90 שניות עם נשימה מודרכת ותזכורת במילים שלו. */
export default function SosScreen({go, close}: {go: (r: string) => void; close: () => void}) {
  const {s, set} = useStore();
  const [left, setLeft] = useState(90);
  const [reason] = useState(s.reasons[Math.floor(Math.random() * s.reasons.length)] || 'אני בוחר בגרסה הטובה שלי');
  const a = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(Animated.sequence([
      Animated.timing(a, {toValue: 1, duration: 4000, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
      Animated.timing(a, {toValue: 0, duration: 4000, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
    ])).start();
    const t = setInterval(() => setLeft(x => (x <= 1 ? 0 : x - 1)), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <ScrollView contentContainerStyle={{paddingBottom: 40}} showsVerticalScrollIndicator={false}>
      <Title style={{fontSize: 30, textAlign: 'center'}}>הגל הזה יעבור</Title>
      <P style={{textAlign: 'center', marginTop: 10}}>
        דחף הוא גל: הוא עולה, מגיע לשיא, ודועך. אתה לא צריך להילחם בו — רק לשבת לידו עד שהוא נגמר.
      </P>

      <Animated.View style={{
        width: 180, height: 180, borderRadius: 90, alignSelf: 'center', marginVertical: 26,
        alignItems: 'center', justifyContent: 'center',
        backgroundColor: 'rgba(255,255,255,0.08)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.26)',
        transform: [{scale: a.interpolate({inputRange: [0, 1], outputRange: [0.82, 1.14]})}],
      }}>
        <Text style={{fontFamily: F.displayMid, fontSize: 17, color: T.txt}}>
          {left > 60 ? 'שאף' : left > 30 ? 'החזק' : 'נשוף'}
        </Text>
      </Animated.View>

      <Text style={{fontFamily: F.display, fontSize: 44, color: T.txt, textAlign: 'center'}}>{left}</Text>

      <Glass style={{marginTop: 20}}>
        <P style={{color: T.txt, fontSize: 15}}>"{reason}"</P>
      </Glass>

      <Btn label="דבר עם המנטור עכשיו" kind="cool" style={{marginTop: 16}} onPress={() => go('mentor')} />
      <Btn label="30 קפיצות, מיד" kind="warm" style={{marginTop: 9}}
        onPress={() => Alert.alert('קום עכשיו', 'שלושים קפיצות. הגוף מוריד את עוצמת הדחף מהר יותר מכל מחשבה.')} />
      <Btn label={left > 0 ? `עוד ${left} שניות` : 'עברתי את זה'} kind="ghost" style={{marginTop: 9}}
        disabled={left > 0} onPress={() => {set({urges: s.urges + 1}); close();}} />
    </ScrollView>
  );
}
