import React from 'react';
import {Text, TouchableOpacity, View, StyleSheet} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {T, F, W} from '../theme';

export const Title = ({children, style}: any) => (
  <Text style={[{fontFamily: F.display, fontWeight: W.display, fontSize: 26, color: T.txt, textAlign: 'right'}, style]}>{children}</Text>
);
export const H2 = ({children, style}: any) => (
  <Text style={[{fontFamily: F.displayMid, fontWeight: W.mid, fontSize: 19, color: T.txt, textAlign: 'right', marginBottom: 10}, style]}>{children}</Text>
);
export const P = ({children, style}: any) => (
  <Text style={[{fontFamily: F.body, fontSize: 14.5, lineHeight: 24, color: T.dim, textAlign: 'right'}, style]}>{children}</Text>
);
export const Tiny = ({children, style}: any) => (
  <Text style={[{fontFamily: F.body, fontSize: 12.5, lineHeight: 19, color: T.dimmer, textAlign: 'right'}, style]}>{children}</Text>
);

type BtnKind = 'hot' | 'warm' | 'cool' | 'ghost';
const FILL: Record<BtnKind, string[]> = {
  hot: [T.rose, '#B4145A'],
  warm: [T.amber, '#E0740B'],
  cool: [T.cyan, T.violet],
  ghost: ['rgba(255,255,255,0.09)', 'rgba(255,255,255,0.04)'],
};

export function Btn({label, onPress, kind = 'ghost', disabled, style}:
  {label: string; onPress?: () => void; kind?: BtnKind; disabled?: boolean; style?: any}) {
  return (
    <TouchableOpacity activeOpacity={0.85} onPress={onPress} disabled={disabled} style={[{opacity: disabled ? 0.34 : 1}, style]}>
      <LinearGradient colors={FILL[kind]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.btn}>
        <Text style={[s.btnT, {color: kind === 'warm' ? '#1a1005' : T.txt}]}>{label}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
}

export const Row = ({children}: any) => <View style={s.row}>{children}</View>;

export function Pill({label, tone}: {label: string; tone?: 'g' | 'r'}) {
  const bg = tone === 'g' ? 'rgba(163,230,53,0.16)' : tone === 'r' ? 'rgba(251,46,107,0.18)' : 'rgba(255,255,255,0.09)';
  const c = tone === 'g' ? '#D9F99D' : tone === 'r' ? '#FFC2D5' : T.dim;
  return (
    <View style={[s.pill, {backgroundColor: bg}]}>
      <Text style={{fontFamily: F.body, fontSize: 11.5, color: c}}>{label}</Text>
    </View>
  );
}

export function Switch({on, onPress}: {on: boolean; onPress: () => void}) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8}>
      <LinearGradient
        colors={on ? [T.violet, T.cyan] : ['rgba(255,255,255,0.13)', 'rgba(255,255,255,0.13)']}
        start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={s.sw}>
        <View style={[s.knob, {alignSelf: on ? 'flex-start' : 'flex-end'}]} />
      </LinearGradient>
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  btn: {paddingVertical: 15, borderRadius: 19, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)'},
  btnT: {fontFamily: F.displayMid, fontWeight: W.mid, fontSize: 15},
  row: {flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.07)'},
  pill: {paddingHorizontal: 10, paddingVertical: 5, borderRadius: 100, borderWidth: 1, borderColor: 'rgba(255,255,255,0.13)'},
  sw: {width: 52, height: 31, borderRadius: 100, padding: 3, justifyContent: 'center', borderWidth: 1, borderColor: T.edge},
  knob: {width: 24, height: 24, borderRadius: 12, backgroundColor: '#fff'},
});
