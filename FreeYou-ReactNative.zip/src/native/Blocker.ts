import {NativeModules, NativeEventEmitter, Platform} from 'react-native';

const {FreeYouBlocker} = NativeModules;

export type Rules = {manual: string[]; autoAdult: boolean; autoScroll: boolean; strict: boolean; reasons: string[]};

/**
 * הגשר אל שירות החסימה בקוטלין.
 * כל מה שקורה כאן ב-JS הוא ממשק בלבד — החסימה עצמה רצה בשירות נייטיב
 * שממשיך לעבוד גם כשהאפליקציה סגורה.
 */
const Blocker = {
  isAvailable: () => Platform.OS === 'android' && !!FreeYouBlocker,

  // האם המשתמש אישר את שירות הנגישות (בלעדיו אין חסימה)
  isAccessibilityEnabled: (): Promise<boolean> =>
    FreeYouBlocker ? FreeYouBlocker.isAccessibilityEnabled() : Promise.resolve(false),
  openAccessibilitySettings: () => FreeYouBlocker?.openAccessibilitySettings(),

  // הרשאת "ציור מעל אפליקציות" — נדרשת כדי לכסות דפדפן חסום
  canDrawOverlays: (): Promise<boolean> =>
    FreeYouBlocker ? FreeYouBlocker.canDrawOverlays() : Promise.resolve(false),
  openOverlaySettings: () => FreeYouBlocker?.openOverlaySettings(),

  // הגנת הסרה: הופכת את FreeYou למנהל התקן כך שאי אפשר למחוק במצב קפדני
  isDeviceAdmin: (): Promise<boolean> =>
    FreeYouBlocker ? FreeYouBlocker.isDeviceAdmin() : Promise.resolve(false),
  requestDeviceAdmin: () => FreeYouBlocker?.requestDeviceAdmin(),
  releaseDeviceAdmin: () => FreeYouBlocker?.releaseDeviceAdmin(),

  // סנכרון רשימות החסימה אל השירות
  syncRules: (r: Rules) =>
    FreeYouBlocker?.syncRules(r.manual, r.autoAdult, r.autoScroll, r.strict, r.reasons),

  // עדכון רשימת הדומיינים האוטומטית (StevenBlack / OISD)
  updateBlocklist: (url: string): Promise<number> =>
    FreeYouBlocker ? FreeYouBlocker.updateBlocklist(url) : Promise.resolve(0),

  // רשימת האפליקציות המותקנות, לבחירה ידנית
  installedApps: (): Promise<{pkg: string; label: string}[]> =>
    FreeYouBlocker ? FreeYouBlocker.installedApps() : Promise.resolve([]),

  // הצלצול של משימת הגוף — שירות חזית שלא נעצר עם האפליקציה
  startAlarm: (nightMode: boolean) => FreeYouBlocker?.startAlarm(nightMode),
  stopAlarm: () => FreeYouBlocker?.stopAlarm(),

  // היעד שהשירות שמר כשעצר כניסה בזמן שהאפליקציה הייתה סגורה
  getPendingRoute: (): Promise<{route: string; target: string; count: number} | null> =>
    FreeYouBlocker ? FreeYouBlocker.getPendingRoute() : Promise.resolve(null),
  clearPendingRoute: () => FreeYouBlocker?.clearPendingRoute(),

  // כמה ניסיונות חסימה נרשמו היום (השירות סופר, לא ה-JS)
  attemptsToday: (): Promise<number> =>
    FreeYouBlocker ? FreeYouBlocker.attemptsToday() : Promise.resolve(0),
};

export const BlockerEvents = FreeYouBlocker ? new NativeEventEmitter(FreeYouBlocker) : null;

/** אירוע 'onBlockAttempt' נשלח בכל פעם שהשירות עצר כניסה. payload: {target, count} */
export default Blocker;
