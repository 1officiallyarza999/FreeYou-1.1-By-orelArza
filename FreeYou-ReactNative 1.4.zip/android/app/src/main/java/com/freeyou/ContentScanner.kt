package com.freeyou

import android.content.Context
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import java.io.File

/**
 * סורק את הטקסט שעל המסך ומזהה תוכן מיני, גם באתר שלא נמצא באף רשימת חסימה.
 *
 * ===== שלוש החלטות שקובעות אם זה נשאר מותקן =====
 *
 * 1. הכל נשאר על המכשיר. אף מילה, כתובת או שבריר טקסט לא נשלחים לשום מקום
 *    ולא נכתבים ללוג. הסורק בכלל לא מחזיק הרשאת רשת — הוא רק מחזיר ניקוד.
 *
 * 2. ניקוד, לא מילה בודדת. מילה אחת לא מפעילה כלום. צריך לעבור רף,
 *    כי "מאמר בעיתון על תעשיית הפורנו" ו"אתר פורנו" נראים דומה למחרוזת
 *    ושונה לגמרי בצפיפות. התראה על כתבה בעיתון או על עמוד רפואי היא
 *    הדרך הבטוחה לגרום למשתמש למחוק את האפליקציה בשבוע השני.
 *
 * 3. יש אפליקציות שלא נסרקות בכלל. בנקאות, מנהלי סיסמאות, בריאות.
 *    אפליקציות הודעות נסרקות רק אם המשתמש הפעיל את זה במפורש — שם
 *    מתנהלות שיחות פרטיות עם בת הזוג, וסריקה שלהן בלי בחירה מודעת
 *    היא חציית קו.
 */
object ContentScanner {

    // מעולם לא נסרק, בשום הגדרה
    private val NEVER = setOf(
        "com.android.settings", "com.freeyou",
        "com.android.vending",            // חנות
        "com.google.android.apps.walletnfcrel",
        "com.android.keychain"
    )
    private val NEVER_PREFIX = listOf(
        "com.bank", "com.leumi", "com.poalim", "com.discount", "com.mizrahi",
        "com.isracard", "com.max.", "com.cal", "com.paypal",
        "com.lastpass", "com.bitwarden", "com.agilebits", "com.dashlane",
        "com.google.android.apps.fitness", "com.samsung.android.app.shealth"
    )
    // נסרקות רק בהסכמה מפורשת (S.scanMessaging)
    private val MESSAGING = setOf(
        "com.whatsapp", "org.telegram.messenger", "com.instagram.android",
        "com.facebook.orca", "com.snapchat.android", "com.google.android.apps.messaging",
        "com.discord", "com.twitter.android", "com.zhiliaoapp.musically"
    )

    /**
     * זרע מינימלי ולא גרפי — סמני קטגוריה בלבד.
     * הלקסיקון האמיתי נטען מקובץ (lexicon.txt) שהמשתמש או רשימה ציבורית
     * מספקים, בפורמט: מילה<טאב>ניקוד. כך אין דיקשנרי מוטבע בקוד,
     * והרשימה מתעדכנת בלי עדכון גרסה.
     */
    private val SEED = mapOf(
        "porn" to 5, "pornhub" to 6, "xvideos" to 6, "xhamster" to 6,
        "xxx" to 4, "nsfw" to 3, "onlyfans" to 5, "camgirl" to 5, "webcam girls" to 5,
        "hentai" to 5, "escort service" to 4, "adult video" to 4, "sex video" to 5,
        "פורנו" to 5, "פורנוגרפיה" to 4, "סרטי מבוגרים" to 5, "תוכן למבוגרים" to 3,
        "שירותי ליווי" to 4, "מצלמות בשידור חי" to 4, "עירום" to 3, "עירומות" to 4,
        "18+" to 2, "כניסה למבוגרים" to 3
    )

    private var lex: Map<String, Int> = SEED
    private var loaded = false

    // רף: צריך צפיפות, לא אזכור
    private const val THRESHOLD = 8
    private const val MIN_DISTINCT = 2      // לפחות שני מונחים שונים
    private const val DEBOUNCE_MS = 1_600L  // לא סורקים על כל שינוי פיקסל
    private const val COOLDOWN_MS = 45_000L // לא מתריעים פעמיים על אותו מסך

    private var lastScan = 0L
    private var lastHit = 0L
    private var lastPkg = ""

    fun init(ctx: Context) {
        if (loaded) return
        val f = File(ctx.filesDir, "lexicon.txt")
        if (f.exists()) {
            val m = HashMap<String, Int>(SEED)
            f.readLines().forEach { line ->
                val p = line.trim().split('\t')
                if (p.size == 2) p[1].toIntOrNull()?.let { m[p[0].lowercase()] = it }
            }
            lex = m
        }
        loaded = true
    }

    fun shouldScan(pkg: String, scanMessaging: Boolean): Boolean {
        if (pkg in NEVER) return false
        if (NEVER_PREFIX.any { pkg.startsWith(it) }) return false
        if (pkg in MESSAGING && !scanMessaging) return false
        return true
    }

    /**
     * מחזיר את הניקוד אם עבר את הרף, אחרת null.
     * לא מחזיר ולא שומר את הטקסט עצמו — רק מספר.
     */
    fun scan(root: AccessibilityNodeInfo?, pkg: String, scanMessaging: Boolean): Int? {
        if (root == null) return null
        if (!shouldScan(pkg, scanMessaging)) return null

        val now = SystemClock.elapsedRealtime()
        if (now - lastScan < DEBOUNCE_MS) return null
        lastScan = now
        if (pkg == lastPkg && now - lastHit < COOLDOWN_MS) return null

        val sb = StringBuilder(2048)
        collect(root, sb, 0)
        val text = sb.toString().lowercase()
        if (text.length < 12) return null

        var score = 0
        var distinct = 0
        lex.forEach { (term, w) ->
            var i = text.indexOf(term)
            if (i >= 0) {
                distinct++
                var hits = 0
                while (i >= 0 && hits < 4) {        // תקרה לכל מונח, שלא ייצור ניקוד מנופח
                    hits++
                    i = text.indexOf(term, i + term.length)
                }
                score += w * hits
            }
        }

        if (score >= THRESHOLD && distinct >= MIN_DISTINCT) {
            lastHit = now
            lastPkg = pkg
            return score
        }
        return null
    }

    /** אוסף טקסט מהעץ. עומק מוגבל וגודל מוגבל — זה רץ הרבה, וסוללה חשובה. */
    private fun collect(n: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > 14 || sb.length > 6000) return
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { collect(it, sb, depth + 1) }
        }
    }

    /** עדכון לקסיקון מרשימה חיצונית, אותו רעיון כמו רשימת הדומיינים */
    fun updateLexicon(ctx: Context, url: String): Int {
        val out = StringBuilder()
        var n = 0
        java.net.URL(url).openStream().bufferedReader().forEachLine { raw ->
            val line = raw.substringBefore('#').trim()
            if (line.isNotEmpty()) {
                val p = line.split('\t')
                val term = p[0].lowercase()
                val w = if (p.size > 1) p[1].toIntOrNull() ?: 3 else 3
                out.append(term).append('\t').append(w).append('\n')
                n++
            }
        }
        File(ctx.filesDir, "lexicon.txt").writeText(out.toString())
        loaded = false
        init(ctx)
        return n
    }
}
