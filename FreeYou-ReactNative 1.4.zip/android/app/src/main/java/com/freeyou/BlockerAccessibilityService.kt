package com.freeyou

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * הלב של החסימה.
 * שירות נגישות רואה איזו אפליקציה בחזית ומה כתוב בשורת הכתובת של הדפדפן,
 * ולכן הוא היחיד שיכול לעצור כניסה לפני שהתוכן נטען — גם ב-Chrome, גם בגלישה פרטית.
 */
class BlockerAccessibilityService : AccessibilityService() {

    // מזהי שורת הכתובת בדפדפנים הנפוצים
    private val urlBars = listOf(
        "com.android.chrome:id/url_bar",
        "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
        "com.brave.browser:id/url_bar",
        "com.opera.browser:id/url_field",
        "com.sec.android.app.sbrowser:id/location_bar_edit_text",
        "com.microsoft.emmx:id/url_bar",
        "com.duckduckgo.mobile.android:id/omnibarTextInput"
    )

    private var lastBlock = 0L
    private var lastTarget = ""

    override fun onServiceConnected() {
        BlockRepo.init(this)
        ContentScanner.init(this)
        MentorOverlay.init(this)   // מכין את מנוע הדיבור מראש, כדי שלא יהיה עיכוב ברגע האמת
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 120
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (MentorOverlay.isShowing()) return   // השכבה כבר מוצגת, לא מפעילים שוב

        val root: AccessibilityNodeInfo = rootInActiveWindow ?: return

        // 1. אתר בדפדפן
        val url = readUrl(root)
        if (url != null) {
            BlockRepo.isUrlBlocked(url)?.let { return intercept(it) }
        }

        // 2. אפליקציה חסומה או מסך פיד
        val hint = event.className?.toString()
        BlockRepo.isAppBlocked(pkg, hint)?.let { return intercept(it) }

        // 3. סריקת הטקסט שעל המסך — תופסת גם אתר שלא נמצא באף רשימה.
        //    מחזיר ניקוד, לא טקסט. שום דבר לא יוצא מהמכשיר.
        if (BlockRepo.scanScreen) {
            ContentScanner.scan(root, pkg, BlockRepo.scanMessaging)?.let {
                return intercept(url ?: pkg, byScan = true)
            }
        }
    }

    private fun readUrl(root: AccessibilityNodeInfo): String? {
        urlBars.forEach { id ->
            val nodes = root.findAccessibilityNodeInfosByViewId(id)
            if (nodes.isNotEmpty()) {
                val t = nodes[0].text?.toString()
                if (!t.isNullOrBlank()) return t
            }
        }
        return null
    }

    /**
     * עצירה: חוזרים אחורה מיד, ואז פותחים את המסך שמתאים למספר הניסיון היום.
     * ניסיון ראשון -> מחברת. ניסיון שני ומעלה -> משימת גוף עם צלצול.
     */
    private fun intercept(target: String, byScan: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (target == lastTarget && now - lastBlock < 4000) return
        lastBlock = now; lastTarget = target

        performGlobalAction(GLOBAL_ACTION_BACK)

        val count = BlockRepo.bumpAttempt()
        val route = if (count <= 1) "journal" else "mission"

        // המנטור עולה מעל הדפדפן מיד, לפני שהאפליקציה נפתחת
        MentorOverlay.show(
            this, count,
            onContinue = {
                BlockRepo.setPendingRoute(route, target, count, byScan)
                sendBroadcast(Intent(ACTION_BLOCKED).apply {
                    setPackage(packageName)
                    putExtra("route", route)
                    putExtra("target", target)
                    putExtra("count", count)
                })
                startActivity(Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                })
            },
            onBack = {
                // הוא בחר לעצור. חוזרים למסך הבית ולא פותחים כלום.
                performGlobalAction(GLOBAL_ACTION_HOME)
            },
        )
    }

    override fun onInterrupt() {}

    companion object {
        const val ACTION_BLOCKED = "com.freeyou.BLOCK_ATTEMPT"
    }
}
