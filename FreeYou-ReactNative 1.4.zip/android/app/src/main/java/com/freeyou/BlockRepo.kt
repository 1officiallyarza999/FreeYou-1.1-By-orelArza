package com.freeyou

import android.content.Context
import java.io.File
import java.net.URL
import java.util.Calendar

/**
 * מחזיק את כללי החסימה ואת מונה הניסיונות.
 * נשמר ב-SharedPreferences + קובץ טקסט לרשימה הגדולה, כדי שהשירות
 * יוכל לקרוא אותם גם כשאפליקציית ה-JS לא רצה.
 */
object BlockRepo {
    private const val PREFS = "freeyou_rules"
    private lateinit var appCtx: Context

    // דומיינים מהרשימה האוטומטית (מוחזק ב-HashSet לחיפוש מיידי)
    private var autoSet: HashSet<String> = HashSet()
    private var loaded = false

    var manual: List<String> = emptyList(); private set
    var reasons: List<String> = emptyList(); private set
    var autoAdult = true; private set
    var autoScroll = false; private set
    var strict = false; private set
    var scanScreen = true; private set        // סריקת טקסט על המסך
    var scanMessaging = false; private set    // אפליקציות הודעות — רק בהסכמה מפורשת

    // פידים של גלילה אינסופית — חוסמים את הפיד, לא את כל האפליקציה
    private val SCROLL_FEEDS = mapOf(
        "com.zhiliaoapp.musically" to listOf("feed", "foryou"),
        "com.instagram.android" to listOf("reels", "explore"),
        "com.google.android.youtube" to listOf("shorts"),
        "com.facebook.katana" to listOf("feed")
    )

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        val p = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        manual = p.getStringSet("manual", emptySet())!!.toList()
        reasons = p.getStringSet("reasons", emptySet())!!.toList()
        autoAdult = p.getBoolean("autoAdult", true)
        autoScroll = p.getBoolean("autoScroll", false)
        strict = p.getBoolean("strict", false)
        scanScreen = p.getBoolean("scanScreen", true)
        scanMessaging = p.getBoolean("scanMessaging", false)
        loadAuto()
    }

    fun save(m: List<String>, adult: Boolean, scroll: Boolean, st: Boolean, rs: List<String>) {
        manual = m; autoAdult = adult; autoScroll = scroll; strict = st; reasons = rs
        appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putStringSet("manual", m.toSet())
            .putBoolean("autoAdult", adult)
            .putBoolean("autoScroll", scroll)
            .putBoolean("strict", st)
            .putStringSet("reasons", rs.toSet())
            .apply()
    }

    private fun file() = File(appCtx.filesDir, "blocklist.txt")

    private fun loadAuto() {
        if (loaded) return
        val f = file()
        if (f.exists()) {
            autoSet = HashSet(f.readLines().filter { it.isNotBlank() })
        }
        loaded = true
    }

    /**
     * הורדת רשימת דומיינים בפורמט hosts (StevenBlack porn, OISD nsfw).
     * מריצים ברקע — מחזיר את מספר הדומיינים שנשמרו.
     */
    fun updateBlocklist(url: String): Int {
        val out = HashSet<String>()
        URL(url).openStream().bufferedReader().forEachLine { raw ->
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) return@forEachLine
            val parts = line.split(Regex("\\s+"))
            val host = if (parts.size >= 2) parts[1] else parts[0]
            if (host.contains('.') && host != "localhost") out.add(host.removePrefix("www."))
        }
        file().writeText(out.joinToString("\n"))
        autoSet = out
        loaded = true
        return out.size
    }

    /** האם כתובת האתר הזו חסומה */
    fun isUrlBlocked(url: String): String? {
        val host = url.removePrefix("https://").removePrefix("http://")
            .substringBefore('/').substringBefore(':').removePrefix("www.").lowercase()
        if (host.isEmpty()) return null
        manual.forEach { m ->
            val n = m.lowercase().trim()
            if (n.isNotEmpty() && host.contains(n)) return host
        }
        if (autoAdult) {
            loadAuto()
            if (autoSet.contains(host)) return host
            // גם תת-דומיינים
            var h = host
            while (h.contains('.')) {
                h = h.substringAfter('.')
                if (autoSet.contains(h)) return host
            }
        }
        return null
    }

    /** האם האפליקציה הזו חסומה (או המסך שלה, במצב גלילה) */
    fun isAppBlocked(pkg: String, screenHint: String?): String? {
        manual.forEach { m ->
            val n = m.lowercase().trim()
            if (n.isNotEmpty() && pkg.lowercase().contains(n)) return pkg
        }
        if (autoScroll) {
            val feeds = SCROLL_FEEDS[pkg] ?: return null
            if (screenHint == null) return pkg
            if (feeds.any { screenHint.lowercase().contains(it) }) return pkg
        }
        return null
    }

    // ---- מונה ניסיונות יומי ----
    private fun dayKey(): String {
        val c = Calendar.getInstance()
        return "${c.get(Calendar.YEAR)}-${c.get(Calendar.DAY_OF_YEAR)}"
    }

    fun bumpAttempt(): Int {
        val p = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = "att_" + dayKey()
        val n = p.getInt(key, 0) + 1
        p.edit().putInt(key, n).apply()
        return n
    }

    // ---- יעד ממתין: לאן לנתב את הממשק ברגע שהוא נפתח ----
    fun setPendingRoute(route: String, target: String, count: Int, byScan: Boolean = false) {
        appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("p_route", route).putString("p_target", target)
            .putInt("p_count", count).putBoolean("p_scan", byScan)
            .apply()
    }

    fun pendingRoute(): Triple<String, String, Int>? {
        val p = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val r = p.getString("p_route", null) ?: return null
        return Triple(r, p.getString("p_target", "") ?: "", p.getInt("p_count", 1))
    }

    fun clearPendingRoute() {
        appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove("p_route").remove("p_target").remove("p_count").apply()
    }

    fun isReady() = ::appCtx.isInitialized

    fun attemptsToday(): Int =
        appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("att_" + dayKey(), 0)
}
