import Tts from 'react-native-tts';
import RNFS from 'react-native-fs';
import Sound from 'react-native-sound';

/**
 * הקול של היצר הטוב.
 *
 * ===== למה שתי שכבות =====
 * ה-TTS המובנה של אנדרואיד בעברית דק ומכני. לא משנה כמה תוריד את הגובה,
 * הוא לא יישמע כמו אח גדול. לכן:
 *
 *   שכבה 1 — ElevenLabs. קול עברי אמיתי, עמוק. זה מה שנשמע.
 *   שכבה 2 — TTS מקומי מכוונן. גיבוי כשאין רשת.
 *
 * ===== למה יש קאש מקומי =====
 * ברגע החסימה אין זמן להמתין לרשת. לכן בהתקנה הראשונה האפליקציה
 * מייצרת מראש את כל בנק המשפטים המקומי כקבצי mp3 ושומרת אותם.
 * מאותו רגע, המשפט ברגע העצירה מתנגן מיד — גם במטוס.
 */

const PROXY = 'https://your-worker.workers.dev/voice';

/**
 * VOICE_ID — בחר מה-Voice Library של ElevenLabs, לא מהקולות הדיפולטיביים.
 * הקולות הדיפולטיביים (Adam וכו') יורדים מהאוויר ב-31.12.2026 ואינם
 * זמינים לחשבונות שנפתחו אחרי מרץ 2026. סנן ב-Voice Library לפי
 * Hebrew + Male + Deep, או שכפל קול משלך ב-Instant Voice Cloning.
 */
export const VOICE_ID = 'REPLACE_WITH_VOICE_LIBRARY_ID';

/** רמת אסרטיביות. משנה גם את הניסוח וגם את הגשה. */
export type Tone = 'brother' | 'coach' | 'hard';

const SETTINGS: Record<Tone, any> = {
  // אח גדול: חם, יציב, לא ממהר
  brother: {stability: 0.55, similarity_boost: 0.8, style: 0.25, speed: 0.96},
  // מאמן: ישיר, קצוב
  coach: {stability: 0.42, similarity_boost: 0.82, style: 0.45, speed: 1.0},
  // קשוח: קצר, נחתך, בלי ריכוך. הכי קרוב למה שביקשת.
  hard: {stability: 0.3, similarity_boost: 0.85, style: 0.7, speed: 1.06},
};

const dir = `${RNFS.DocumentDirectoryPath}/voice`;
const key = (t: string, tone: Tone) => {
  let h = 0;
  const s = tone + '|' + t;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return `${dir}/${Math.abs(h).toString(36)}.mp3`;
};

/** String.fromCharCode על מערך של מאות קילובייט עורם את הסטאק. בבלוקים זה בטוח. */
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function toBase64(b: Uint8Array): string {
  let out = '';
  for (let i = 0; i < b.length; i += 3) {
    const n = (b[i] << 16) | ((b[i + 1] || 0) << 8) | (b[i + 2] || 0);
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] +
      (i + 1 < b.length ? B64[(n >> 6) & 63] : '=') +
      (i + 2 < b.length ? B64[n & 63] : '=');
  }
  return out;
}

let current: Sound | null = null;

export function stop() {
  current?.stop();
  current?.release();
  current = null;
  Tts.stop();
}

async function play(path: string) {
  return new Promise<void>(res => {
    stop();
    const s = new Sound(path, '', err => {
      if (err) return res();
      current = s;
      s.play(() => {
        s.release();
        current = null;
        res();
      });
    });
  });
}

/** מוריד קליפ ושומר בקאש. מחזיר את הנתיב, או null אם אין רשת. */
async function fetchClip(text: string, tone: Tone): Promise<string | null> {
  const path = key(text, tone);
  if (await RNFS.exists(path)) return path;
  try {
    await RNFS.mkdir(dir);
    const r = await fetch(PROXY, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        voice_id: VOICE_ID,
        // flash: השהיה נמוכה, מה שצריך לשיחה חיה. למשפטי הקאש אפשר v3.
        model_id: 'eleven_flash_v2_5',
        text,
        voice_settings: SETTINGS[tone],
      }),
    });
    if (!r.ok) return null;
    const bytes = new Uint8Array(await r.arrayBuffer());
    await RNFS.writeFile(path, toBase64(bytes), 'base64');
    return path;
  } catch {
    return null;
  }
}

/** גיבוי מקומי: מכוונן לכמה שיותר בס ופחות זמזום */
function fallback(text: string, tone: Tone) {
  Tts.setDefaultLanguage('he-IL');
  Tts.setDefaultPitch(tone === 'hard' ? 0.62 : 0.72); // הגובה הנמוך ביותר שעוד מובן
  Tts.setDefaultRate(tone === 'hard' ? 0.52 : 0.46);
  Tts.stop();
  Tts.speak(text);
}

/**
 * אומר משפט. קאש קודם, רשת אחר כך, TTS מקומי בסוף.
 * instant=true — לרגע העצירה: אם אין קליפ בקאש, לא מחכים לרשת בכלל.
 */
export async function say(text: string, tone: Tone = 'coach', instant = false) {
  const path = key(text, tone);
  if (await RNFS.exists(path)) return play(path);
  if (instant) {
    fallback(text, tone);                    // מדבר עכשיו
    fetchClip(text, tone);                   // ומכין לפעם הבאה
    return;
  }
  const p = await fetchClip(text, tone);
  if (p) return play(p);
  fallback(text, tone);
}

/**
 * מריצים פעם אחת אחרי ההתקנה, על wifi.
 * מייצר מראש את כל בנק המשפטים כך שרגע העצירה תמיד מיידי ותמיד בקול האמיתי.
 */
export async function warmCache(lines: string[], tone: Tone, onProgress?: (n: number, total: number) => void) {
  let n = 0;
  for (const l of lines) {
    await fetchClip(l, tone);
    onProgress?.(++n, lines.length);
  }
  return n;
}
